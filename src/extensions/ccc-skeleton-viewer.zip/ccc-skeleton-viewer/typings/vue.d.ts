declare var Vue: any;
